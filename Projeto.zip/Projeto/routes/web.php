<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/edit', function() {
	return view('edit');
});
Route::get('/colecao', function(){
	return view('colecao');
});
Route::get('/escolha', function(){
	return view('escolha');
});
Route::get('/editColecao', function(){
	return view('editColecao');
});
Route::get('/visuColecao', function(){
	return view('visuColecao');
});
Route::get('/excluirColecao', function(){
	return view('excluirColecao');
});



Route::get('colecao-edit','ColecaoController@editColecao')->name('EditColecao')->middleware('auth');
Route::get('colecao-register','ColecaoController@RegisterColecao')->name('RegisterColecao')->middleware('auth');


Route::get('editar-perfil','EditController@editPerfil')->name('editPerfil')->middleware('auth');
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
