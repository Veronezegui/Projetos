<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;

class colecao extends Model
{
	protected $table = 'itens';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    public $fillable = [
        'nome_colecao', 'nome_item', 'descricao',
    ];

 }
