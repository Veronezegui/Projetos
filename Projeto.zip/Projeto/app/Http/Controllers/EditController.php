<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class EditController extends Controller
{
    public function editPerfil(Request $request)
    {

    	$data = $request->all();

    	if ($data['password'] != null)
    		$data['password'] = bcrypt($data['password']);
    	
    	else
    	 	unset($data['password']);
    	$update = auth()->user()->update($data);

    	if ($update)
    		return redirect('/edit')
    				->with('success','Sucesso ao atualizar');
    	

    	return redirect()
    				->back()
    				->with('error', 'Falha ao atualizar o perfil');
    	
    }
}
