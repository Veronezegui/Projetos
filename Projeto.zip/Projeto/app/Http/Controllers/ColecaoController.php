<?php

use App\colecao;
namespace App\Http\Controllers;


use Illuminate\Http\Request;

class ColecaoController extends Controller
{

    protected $fillable = ['nome_colecao', 'nome_item', 'descricao'];

	public function validateColecao(array $data)
    {
        return Validator::make($data, [
            'nome_colecao' => ['string', 'max:60'],
            'nome_item' => ['string','max:60', 'unique:users'],
            'descricao' => ['string', 'max:191'],
        ]);
    }
    public function RegisterColecao(Request $request)
    {
    	$data = $request->all();

        $insert = auth()->user()->insert($data);
        if ($insert) 
        	return redirect('/escolha')
    				->with('success','Sucesso ao cadastrar');

    	return redirect()
                    ->back()
                    ->with('error', 'Falha ao atualizar o perfil');
    }
    public function EditColecao(Request $request)
    {

        $data = $request->all();

        $update = auth()->user()->update($data);

        if ($update)
            return redirect('/editColecao')
                    ->with('success','Sucesso ao atualizar');
        

        return redirect()
                    ->back()
                    ->with('error', 'Falha ao atualizar coleção');
        
    }
}
