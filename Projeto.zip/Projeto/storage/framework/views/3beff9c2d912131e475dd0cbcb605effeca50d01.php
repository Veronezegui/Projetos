<?php /* C:\xampp\htdocs\Projeto\resources\views/escolha.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    
                        <?php echo csrf_field(); ?>

                        
                        <div class="form-group row mb-0">
                            <ul>
                                <li>
                                    <a class="nav-link" href="<?php echo e(url('/visuColecao')); ?>"><?php echo e(__('Visualizar meus itens')); ?></a>
                                </li>
                            <hr>
                          
                                <li>
                                    <a class="nav-link" href="<?php echo e(url('/colecao')); ?>"><?php echo e(__('Cadastrar coleção')); ?></a>
                                </li>
                            <hr>
                           
                                <li>
                                    <a class="nav-link" href="<?php echo e(url('/editColecao')); ?>"><?php echo e(__('Editar coleção')); ?></a>
                                </li>
                            <hr> 
                                <li>
                                    <a class="nav-link" href="<?php echo e(url('/excluirColecao')); ?>"><?php echo e(__('Excluir coleção')); ?></a>
                                </li> 
                            </ul>
                        </div>
                  
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>