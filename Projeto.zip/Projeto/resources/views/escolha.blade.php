@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    
                        @csrf

                        
                        <div class="form-group row mb-0">
                            <ul>
                                <li>
                                    <a class="nav-link" href="{{ url('/visuColecao') }}">{{ __('Visualizar meus itens') }}</a>
                                </li>
                            <hr>
                          
                                <li>
                                    <a class="nav-link" href="{{ url('/colecao') }}">{{ __('Cadastrar coleção') }}</a>
                                </li>
                            <hr>
                           
                                <li>
                                    <a class="nav-link" href="{{ url('/editColecao') }}">{{ __('Editar coleção') }}</a>
                                </li>
                            <hr> 
                                <li>
                                    <a class="nav-link" href="{{ url('/excluirColecao') }}">{{ __('Excluir coleção') }}</a>
                                </li> 
                            </ul>
                        </div>
                  
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
